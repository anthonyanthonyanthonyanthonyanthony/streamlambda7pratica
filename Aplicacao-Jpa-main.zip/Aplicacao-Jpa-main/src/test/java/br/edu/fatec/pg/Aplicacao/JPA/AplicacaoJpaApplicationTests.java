package br.edu.fatec.pg.Aplicacao.JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
