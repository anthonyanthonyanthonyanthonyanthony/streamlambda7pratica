package br.edu.fatecpg.apiMkt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMktApplicationTests {

	@Test
	void contextLoads() {
	}

}
